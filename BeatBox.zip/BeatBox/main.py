from flask import Flask, render_template, send_from_directory

app = Flask(__name__, template_folder='Spotify_website/templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/song1.html')
def song1():
    return render_template('song1.html')

@app.route('/song2.html')
def song2():
    return render_template('song2.html')

@app.route('/song3.html')
def song3():
    return render_template('song3.html')

# Route to serve files from the 'assets' folder
@app.route('/assets/<path:filename>')
def assets(filename):
    return send_from_directory('Spotify_website/assets', filename)

# Route to serve images from the 'images' folder
@app.route('/images/<path:filename>')
def images(filename):
    return send_from_directory('Spotify_website/assets/images', filename)

# Route to serve CSS files from the 'css' folder
@app.route('/css/<path:filename>')
def css(filename):
    return send_from_directory('Spotify_website/assets/css', filename)

if __name__ == '__main__':
    app.run(debug=True)
